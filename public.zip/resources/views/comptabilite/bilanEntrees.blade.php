@extends('skeleton')
@section('sub-content')
<div class="col-md-12">
    @if(isset($success))

        <div class="alert alert-success">
            {{  trans('admin.succes')  }}
        </div>

    @endif


        <div class="col-md-8" >
            <div class="btn-group" >
                <a href="{{url('/comptabilite/bilan/entrees').'?option=year'}}" class="btn btn-success"> @lang('admin.toute_lannee')</a>
                <a href="{{url('/comptabilite/bilan/entrees').'?option=month'}}" class="btn btn-info"> @lang('admin.mois')</a>
                <a href="{{url('/comptabilite/bilan/entrees').'?option=week'}}" class="btn btn-warning"> @lang('admin.semaine')</a>

            </div>

            <h4 style="margin-top: 15px;">
                @if(isset($date_debut))
                    {{$date_debut.' - '.$date_fin}}
                @else
                    {{$table_titre}}
                @endif

            </h4>
            <table id="table-entrees" class="table table-bordered table-striped table-condensed table-inverse" >
                <thead>
                <th>#</th>
                <th>{{trans('inscription.motif')}}</th>
                <th>Date</th>
                <th>@lang('inscription.montant')</th>
                <th></th>
                </thead>
                <tbody>
                <?php $i=1; ?>
                @foreach($payements as $p)
                    <tr>
                        <td>{{$i++}}</td>
                        <td><strong >{{$p->motif}}</strong></td>
                        <td>{{(new DateTime($p->date_payement))->format('d-m-Y')}}</td>
                        <td>{{$p->montant}}</td>
                        <td>                        <a  class="btn btn-warning"  href="@if($p->motif=='Inscription'){{URL::to('/inscriptions/print/'.$p->id)}} @else{{URL::to('/inscriptions/payement/print/'.$p->id)}}@endif" ><span class="glyphicon glyphicon-eye-open"  ></span> {{  trans('admin.verifier')  }}</a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>

           <!-- <div class="paginate" style="text-align: center;"> <?php /*echo(str_replace('/?', '?', $payements->render()) );*/ ?></div> -->

            <h4 class="alert alert-warning">
                Total : <strong>{{$total.' '.trans('inscription.devise')}} </strong>
            </h4>
        </div>
    <div class="col-md-4">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="panel-title">@lang('admin.intervalle')</div>

            </div>
            <div class="panel-body">
                <form accept-charset="UTF-8" role="form" method="POST" action="{{ url('/comptabilite/bilan/entrees') }}">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <fieldset>

                        <div class="form-group">
                            <label for="date_debut">{{  trans('admin.date_debut')  }} : </label>
                            <input placeholder="jj-mm-aaaa" class="form-control" id="date_debut" name="date_debut" type="date"  value="{{ old('date_debut') }}" required>

                        </div>
                        <div class="form-group ">
                            <label for="date_fin">{{  trans('admin.date_fin')  }} : </label>
                            <input placeholder="jj-mm-aaaa" class="form-control" id="date_fin" name="date_fin" type="date"  value="{{ old('date_fin') }}" required >

                        </div>
                        <input placeholder="jj-mm-aaaa" class="btn  btn-primary pull-right " type="submit" value="{{  trans('admin.confirmer')  }}">


                    </fieldset>
                </form>
            </div>
        </div>
    </div>




</div>
    <script>

        $('#table-entrees').dataTable( {
            dom: 'Bfrtip',
            buttons: [
                //'copy', 'csv', 'excel', 'pdf', 'print'
                {
                    extend: 'excelHtml5',
                    text: '<i class="fa fa-file-excel-o"></i> Excel',
                    titleAttr: 'Export to Excel',
                    title: 'Bilan entrées {{$table_titre}}',
                    exportOptions: {
                        columns: ':not(:last-child)'
                    }
                }
                ,
                {
                    extend: 'pdfHtml5',
                    text: '<i class="fa fa-file-pdf-o"></i> PDF',
                    titleAttr: 'PDF',
                    title: 'Bilan entrées {{$table_titre}}',
                    exportOptions: {
                        columns: ':not(:last-child)'
                    }
                }
                ,
                {
                    extend: 'print',
                    text: '<i class="fa fa-print"></i> @lang("inscription.imprimer")',
                    titleAttr: 'Imprimer',
                    title: 'Bilan entrées {{$table_titre}}',
                    exportOptions: {
                        columns: ':not(:last-child)'
                    }
                }
            ]
        } );
        $(function () {
            //$('#date_debut').datepicker({ dateFormat: 'dd-mm-yy' });
            //$('#date_fin').datepicker({ dateFormat: 'dd-mm-yy' });
        });


    </script>
@endsection